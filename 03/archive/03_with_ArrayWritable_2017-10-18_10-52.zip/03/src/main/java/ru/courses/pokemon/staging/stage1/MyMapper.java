package ru.courses.pokemon.staging.stage1;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;
import java.util.*;

// Mapper <KeyIn, ValueIn, KeyOut, Value Out> - на выходе слово и частота его повторения
public class MyMapper extends Mapper<WritableComparable, Text, Text, ArrayWritable> {
    final static String SEP = ";";

    @Override // Переопределяем обязательно!
    protected void map(WritableComparable key, Text value, Context context) throws IOException, InterruptedException {

        // value - это строка файла
        // у полей есть разделители ";"

        // разделяем входную строку по ";", но сначала в String
        String string = value.toString();
        String[] sts = string.split(SEP); // Массив слов

        // на редьюсер нужно отправить ключ и значение
        Text keyOut = new Text(sts[2]); // В качестве выходного ключа ТИП покемона, т.е. 2 элемент массива
        String[] stsOut = {
                sts[1], // 1-name
                sts[3], // 3-hp
                "" + Integer.parseInt(sts[4]) + Integer.parseInt(sts[6]), // 4-attack + 6-special attack - Чтобы учитывать и обычные, и специальные атаки
                "" + Integer.parseInt(sts[5]) + Integer.parseInt(sts[7]), // 5-defense + 7-special defense - Чтобы учитывать и обычные, и специальные защиты
                sts[8] // 8-speed
        }; // То есть сформировали массив вида [0-name, 1-hp, 2-attack, 3-defence, 4-speed], чтобы на редьюсер отдавать такого вида массивы
        ArrayWritable valueOut = new ArrayWritable(stsOut); // Оборачиваем выходной массив-значение в обертку ArrayWritable

        // на редьюсер нужно отправить ключ и значение
        context.write(keyOut, valueOut); // И записываем в контекст
    }


}